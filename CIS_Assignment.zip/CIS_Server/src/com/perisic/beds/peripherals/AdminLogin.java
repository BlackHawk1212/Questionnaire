package com.perisic.beds.peripherals;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import com.perisic.beds.rmiserver.AdminDash;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;

public class AdminLogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4039190054916137576L;
	private JPanel contentPane;
	private JPasswordField password;
	private JTextField username;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		this.setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 681, 452);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(100, 149, 237));
		panel.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel.setBounds(0, 0, 665, 413);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1.setBackground(new Color(100, 149, 237));
		panel_1.setBounds(20, 21, 624, 98);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label1 = new JLabel("Welcome to Sri Lanka Telecom");
		label1.setFont(new Font("Tahoma", Font.BOLD, 35));
		label1.setBounds(41, 30, 551, 37);
		panel_1.add(label1);
		
		password = new JPasswordField();
		password.setFont(new Font("Tahoma", Font.BOLD, 15));
		password.setBounds(224, 246, 311, 30);
		panel.add(password);
		
		JLabel label3 = new JLabel("Password:");
		label3.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label3.setBounds(64, 243, 115, 30);
		panel.add(label3);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String user = username.getText();
				String pass = password.getText();
				
				if(user.contains("admin") && pass.contains("admin123")) {
					username.setText(null);
					password.setText(null);
					systemExit();
					AdminDash q = new AdminDash();
					q.setVisible(true);
					q.setLocationRelativeTo(null);
					q.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					AdminLogin.this.dispose();
				}
				
				else if(user.isEmpty() && pass.isEmpty()) {
						JOptionPane.showMessageDialog(null, "Please enter Login Credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Invalid Login Credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
					username.setText(null);
					password.setText(null);
				}
			}
		});
		
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnLogin.setBounds(178, 322, 133, 45);
		panel.add(btnLogin);
		
		JLabel label2 = new JLabel("User Name:");
		label2.setFont(new Font("Tahoma", Font.PLAIN, 22));
		label2.setBounds(47, 184, 126, 30);
		panel.add(label2);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				username.setText("");
				password.setText("");
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnReset.setBounds(402, 322, 133, 45);
		panel.add(btnReset);
		
		username = new JTextField();
		username.setFont(new Font("Tahoma", Font.BOLD, 15));
		username.setBounds(225, 184, 310, 30);
		panel.add(username);
		username.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainDash fdb = new MainDash();
				fdb.setVisible(true);
				fdb.setLocationRelativeTo(null);
				fdb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				AdminLogin.this.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(30, 130, 89, 27);
		panel.add(btnBack);
	}
	
	//Variable Declaration - Do not modify
	
	private javax.swing.JButton btnBack;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnReset;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
	
	//End of variable declaration
	
	private void systemExit() {
		WindowEvent winClose = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
	}
	
}

