package com.perisic.beds.peripherals;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import com.perisic.beds.questionnaire.QuestionSet;
import com.perisic.beds.rmiinterface.RemoteQuestions;
import com.perisic.beds.rmiserver.AdminDash;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.RemoteException;
import java.util.EventListener;
import java.util.Vector;

import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFormattedTextField;
import javax.swing.JSlider;
import javax.swing.JTextPane;
import java.awt.TextField;

public class Feedback extends JFrame implements ActionListener {

	private QuestionSet questionnaire = new QuestionSet();


	/**
	 * 
	 */
	private static final long serialVersionUID = -8428590640233967435L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField email;
	private JButton finishfb;
	private JButton ansQs;

	int qs = 1;
	int op = 1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Feedback frame = new Feedback();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Feedback() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1203, 603);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel.setBackground(new Color(100, 149, 237));
		panel.setBounds(0, 0, 1187, 564);
		contentPane.add(panel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1.setBackground(new Color(100, 149, 237));
		panel_1.setBounds(21, 179, 1143, 361);
		panel.add(panel_1);

		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBounds(24, 21, 88, 31);
		panel_1.add(lblNewLabel_1);

		name = new JTextField();
		name.setFont(new Font("Tahoma", Font.PLAIN, 20));
		name.setColumns(10);
		name.setBounds(269, 21, 401, 33);
		panel_1.add(name);

		JLabel lblNewLabel_2 = new JLabel("Employee Status:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_2.setBounds(24, 78, 222, 32);
		panel_1.add(lblNewLabel_2);

		JComboBox status = new JComboBox();
		status.setModel(new DefaultComboBoxModel(new String[] {"Select an option", "Permanant Employee", "Trainee Employee"}));
		status.setFont(new Font("Tahoma", Font.PLAIN, 20));
		status.setBounds(269, 78, 282, 31);
		panel_1.add(status);

		email = new JTextField();
		email.setFont(new Font("Tahoma", Font.PLAIN, 20));
		email.setColumns(10);
		email.setBounds(269, 142, 602, 33);
		panel_1.add(email);

		JLabel lblNewLabel_2_2 = new JLabel("Email:");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_2_2.setBounds(24, 142, 222, 32);
		panel_1.add(lblNewLabel_2_2);

		JButton ansQs = new JButton("Answer Questions");
		ansQs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource().equals(ansQs)) { 

					for(int i = 0; i < questionnaire.numberOfQuestions(); i++) {

						String message = questionnaire.getQuestion(i); 
						String [] options = questionnaire.getOptions(i); 

						int selectedValue = JOptionPane.showOptionDialog(null,message, "Question "+i, JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE, null, options, options[0]);  

						questionnaire.submitAnswer(i, options[selectedValue]);
					}
				} else if(e.getSource().equals(finishfb)) { 
					questionnaire.reportAnswers(); 
				}
			}
		});
		ansQs.setFont(new Font("Tahoma", Font.PLAIN, 16));
		ansQs.setBounds(925, 231, 189, 31);
		panel_1.add(ansQs);

		JButton finishfb = new JButton("Finished");
		finishfb.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminDash fdb = new AdminDash();
				fdb.setVisible(true);
				fdb.setLocationRelativeTo(null);
				fdb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				Feedback.this.dispose();
			}
		});
		finishfb.setFont(new Font("Tahoma", Font.PLAIN, 16));
		finishfb.setBounds(387, 304, 363, 29);
		panel_1.add(finishfb);

		JPanel panel_1_1_2 = new JPanel();
		panel_1_1_2.setLayout(null);
		panel_1_1_2.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1_1_2.setBackground(new Color(100, 149, 237));
		panel_1_1_2.setBounds(21, 24, 1143, 107);
		panel.add(panel_1_1_2);

		JLabel headlbl = new JLabel("Sri Lanka Telecom");
		headlbl.setFont(new Font("Tahoma", Font.BOLD, 45));
		headlbl.setBounds(396, 11, 416, 54);
		panel_1_1_2.add(headlbl);

		JLabel subheadlbl = new JLabel("Feel free to fill this questionnaire to improve our employee satisfaction");
		subheadlbl.setFont(new Font("Tahoma", Font.PLAIN, 16));
		subheadlbl.setBounds(350, 60, 507, 21);
		panel_1_1_2.add(subheadlbl);

		JButton btnBack = new JButton("Back");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainDash fdb = new MainDash();
				fdb.setVisible(true);
				fdb.setLocationRelativeTo(null);
				fdb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				Feedback.this.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(35, 141, 88, 27);
		panel.add(btnBack);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
