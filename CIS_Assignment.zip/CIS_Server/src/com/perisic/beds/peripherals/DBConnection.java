package com.perisic.beds.peripherals;

import java.sql.Connection;
import java.sql.DriverManager;

public final class DBConnection {

    public static Connection connect(){
        
       
    
        Connection con = null;
         
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sltdb","root","");
            System.out.println("Connection successful");
        } 
        catch (Exception e) {
            
            System.out.println(e);
            
        }
        return con;
    }

}